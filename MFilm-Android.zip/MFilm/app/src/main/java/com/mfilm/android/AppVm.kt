package com.mfilm.android

import android.app.Application
import android.content.Context
import android.graphics.Bitmap
import android.media.MediaActionSound
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.*
import java.io.File
import kotlin.math.log2
import kotlin.math.max

enum class Screen { HOME, SHELF, CAMERA, DARKROOM, PRINTS, SETTINGS }
enum class ShelfMode { LOAD, DEVELOP }
class Speed(val seg: String, val label: String, val ns: Long)
data class Note(val id: Long, val text: String)
data class DevState(
    val running: Boolean = false, val done: Int = 0, val total: Int = 0,
    val thumbs: List<Bitmap> = emptyList(), val finished: Boolean = false, val error: String? = null
)

class AppVm(private val app: Application) : AndroidViewModel(app) {
    companion object {
        val speeds = listOf(
            Speed("A", "A", 0L), Speed("1000", "1/1000", 1_000_000L), Speed("500", "1/500", 2_000_000L),
            Speed("250", "1/250", 4_000_000L), Speed("125", "1/125", 8_000_000L), Speed("60", "1/60", 16_666_667L),
            Speed("30", "1/30", 33_333_333L), Speed("15", "1/15", 66_666_667L), Speed("8", "1/8", 125_000_000L),
            Speed("4", "1/4", 250_000_000L), Speed("2", "1/2", 500_000_000L)
        )
    }

    val store = RollStore(app)
    val prefs = Prefs(app)
    val camera = CameraController(app)

    var screen by mutableStateOf(Screen.HOME); private set
    var shelfMode by mutableStateOf(ShelfMode.LOAD); private set
    var rolls by mutableStateOf(store.loadAll()); private set
    var activeId by mutableStateOf(prefs.activeRoll); private set
    var selectedId by mutableStateOf<String?>(null); private set
    var devFilm by mutableStateOf<Film?>(null); private set
    var shutterIdx by mutableStateOf(0)
    var note by mutableStateOf<Note?>(null); private set
    var busy by mutableStateOf(false); private set
    var dev by mutableStateOf(DevState()); private set
    @Volatile var deviceRot = 0

    private var devJob: Job? = null
    private val sound = MediaActionSound().apply { load(MediaActionSound.SHUTTER_CLICK); load(MediaActionSound.FOCUS_COMPLETE) }

    init { runCatching { camera.prepare() } }

    val active: Roll? get() = rolls.firstOrNull { it.id == activeId }
    /** The roll that is physically in the camera. */
    val inCamera: Roll? get() = active?.takeIf { it.state == RollState.LOADED || it.state == RollState.FINISHED }
    val selected: Roll? get() = rolls.firstOrNull { it.id == selectedId }

    // ------------------------------------------------------------ navigation
    fun go(s: Screen) { note = null; screen = s }
    fun back() {
        note = null
        screen = when (screen) {
            Screen.SHELF -> if (shelfMode == ShelfMode.DEVELOP) Screen.DARKROOM else Screen.HOME
            else -> Screen.HOME
        }
    }
    fun openShelf(mode: ShelfMode) { shelfMode = mode; screen = Screen.SHELF }
    fun openDarkroom(id: String) {
        selectedId = id; devFilm = null
        if (devJob?.isActive != true) dev = DevState()
        screen = Screen.DARKROOM
    }
    fun openPrints(id: String) { selectedId = id; screen = Screen.PRINTS }
    fun pickFilm(film: Film, frames: Int) {
        if (shelfMode == ShelfMode.LOAD) loadRoll(film, frames) else { devFilm = film; screen = Screen.DARKROOM }
    }

    // ------------------------------------------------------------ helpers
    fun say(t: String) { note = Note(System.nanoTime(), t) }
    private fun haptic(ms: Long = 18, amp: Int = 120) {
        runCatching {
            (app.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator)
                .vibrate(VibrationEffect.createOneShot(ms, amp))
        }
    }
    private fun update(r: Roll) { store.save(r); rolls = rolls.map { if (it.id == r.id) r else it } }

    // ------------------------------------------------------------ roll handling
    fun loadRoll(film: Film, total: Int) {
        val cur = inCamera
        if (cur != null && (cur.shot > 0 || cur.state == RollState.FINISHED)) {
            say("Finish the roll in the camera first"); screen = Screen.HOME; return
        }
        if (cur != null) store.delete(cur.id)          // unload an empty roll
        val r = store.create(film, total)
        rolls = store.loadAll(); activeId = r.id; prefs.setActive(r.id); screen = Screen.HOME
    }

    fun finishRoll() {
        val r = inCamera ?: return
        if (r.shot == 0) return
        if (prefs.realistic) { update(r.copy(state = RollState.FINISHED, wound = false)); say("Hold VOL- in the camera to rewind") }
        else { update(r.copy(state = RollState.REWOUND, wound = false)); openDarkroom(r.id) }
    }

    // ------------------------------------------------------------ exposure
    fun effectiveNs(): Long {
        val r = inCamera ?: return 0L
        val s = speeds[shutterIdx]
        if (s.ns > 0) return s.ns
        val ae = camera.ae
        return (ae.timeNs.toDouble() * ae.iso / r.film.iso).toLong()
    }
    /** Positive = the film would be over-exposed relative to what the phone's meter reads. */
    fun meterStops(): Float {
        val r = inCamera ?: return 0f
        val ae = camera.ae
        val t = max(1L, effectiveNs())
        return log2((t.toDouble() * r.film.iso) / (ae.timeNs.toDouble() * ae.iso)).toFloat().coerceIn(-3f, 3f)
    }

    // ------------------------------------------------------------ the three controls
    /** VOLUME UP */
    fun shutter() {
        val r = inCamera ?: return
        if (screen != Screen.CAMERA || busy) return
        if (r.state != RollState.LOADED || r.shot >= r.total) { say("END OF ROLL"); return }
        if (!r.wound) { say("WIND ON"); haptic(); return }
        busy = true
        val ext = if (camera.rawOk) "dng" else "jpg"
        val dest = File(store.dir(r.id), "frame_%02d.%s".format(r.shot + 1, ext))
        val meter = meterStops()
        val rot = (camera.sensorOrientation + deviceRot) % 360
        if (prefs.sound) sound.play(MediaActionSound.SHUTTER_CLICK)
        haptic(25, 200)
        camera.capture(effectiveNs(), r.film.iso, rot, dest) { f ->
            viewModelScope.launch(Dispatchers.Main) {
                busy = false
                if (f == null) { say("Misfire - frame not exposed"); return@launch }
                commitShot(f.copy(meter = meter))
            }
        }
    }

    private fun commitShot(f: Frame) {
        val r = inCamera ?: return
        var n = r.copy(shot = r.shot + 1, wound = false, frames = r.frames + f)
        if (n.shot >= n.total) {
            if (prefs.realistic) {
                n = n.copy(state = RollState.FINISHED); update(n); say("END - hold VOL- to rewind")
            } else {
                n = n.copy(state = RollState.REWOUND); update(n); openDarkroom(n.id)
            }
            return
        }
        if (!prefs.manualWind) n = n.copy(wound = true)
        update(n)
    }

    /** VOLUME DOWN (short press) */
    fun wind() {
        val r = inCamera ?: return
        if (screen != Screen.CAMERA) return
        when {
            r.state != RollState.LOADED || r.shot >= r.total -> say("END")
            r.wound -> haptic(8, 60)
            else -> {
                update(r.copy(wound = true))
                if (prefs.sound) sound.play(MediaActionSound.FOCUS_COMPLETE)
                haptic(30, 160)
            }
        }
    }

    /** VOLUME DOWN (hold) */
    fun rewind() {
        val r = inCamera ?: return
        val can = r.state == RollState.FINISHED || (prefs.realistic && r.state == RollState.LOADED && r.shot > 0)
        if (!can) { if (!prefs.realistic) say("Basic mode: use Finish roll"); return }
        update(r.copy(state = RollState.REWOUND, wound = false))
        haptic(250, 200)
        say("Rewound - ready to develop")
        screen = Screen.HOME
    }

    // ------------------------------------------------------------ darkroom
    fun stopDevelop() { devJob?.cancel(); devJob = null; dev = DevState() }

    fun develop(roll: Roll, film: Film) {
        if (devJob?.isActive == true) return
        dev = DevState(running = true, total = roll.frames.size)
        devJob = viewModelScope.launch(Dispatchers.Default) {
            try {
                val dir = store.dir(roll.id)
                val folder = roll.id.removePrefix("roll_") + "_" + film.title.replace(Regex("[^A-Za-z0-9]+"), "-")
                val uris = ArrayList<String>(); val thumbs = ArrayList<Bitmap>()
                val sample = if (prefs.halfSize) 2 else 1
                roll.frames.forEachIndexed { i, f ->
                    ensureActive()
                    val src = Developer.decode(File(dir, f.file), sample)
                    val out = Developer.develop(src, film, f, roll.id.hashCode() + i * 7919, prefs.dateStamp)
                    uris += Developer.save(app, out, folder, "MFilm_%02d".format(i + 1), film, f, prefs.quality)
                    val s = 360f / max(out.width, out.height)
                    thumbs += Bitmap.createScaledBitmap(out, (out.width * s).toInt(), (out.height * s).toInt(), true)
                    out.recycle()
                    withContext(Dispatchers.Main) { dev = dev.copy(done = i + 1, thumbs = thumbs.toList()) }
                }
                val sheet = Developer.contactSheet(thumbs, film, roll.id.removePrefix("roll_"))
                val sheetUri = Developer.saveBitmap(app, sheet, folder, "ContactSheet", 90)
                sheet.recycle()
                withContext(Dispatchers.Main) {
                    update(roll.copy(state = RollState.DEVELOPED, printUris = uris, printFilmId = film.id, sheetUri = sheetUri))
                    dev = dev.copy(running = false, finished = true)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                withContext(Dispatchers.Main) { dev = dev.copy(running = false, error = e.message ?: e.javaClass.simpleName) }
            }
        }
    }

    override fun onCleared() { camera.closeBlocking(); sound.release() }
}

package com.mfilm.android

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs

// ------------------------------------------------------------------ HOME
@Composable
fun HomeScreen(vm: AppVm) {
    val cam = vm.inCamera
    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(vertical = 16.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("M-Film", color = Amber, fontSize = 34.sp, fontWeight = FontWeight.Bold)
                    Text("Your phone, shot like film.", color = Dim)
                }
                TextButton(onClick = { vm.go(Screen.SETTINGS) }) { Text("Settings") }
            }
        }
        vm.note?.let { n -> item(key = "note") { Text(n.text, color = Amber, fontWeight = FontWeight.SemiBold) } }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Ink2)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (cam == null) {
                        Text("No roll in the camera", color = Color.White, fontSize = 18.sp)
                        Button(onClick = { vm.openShelf(ShelfMode.LOAD) }) { Text("Load a roll") }
                    } else {
                        Text(cam.film.title, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        val c = if (cam.counter == 0) "S" else cam.counter.toString()
                        Text("ISO ${cam.film.iso}  ·  frame $c / ${cam.total}  ·  ${cam.shot} shot", color = Dim)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { vm.go(Screen.CAMERA) }) { Text("Shoot") }
                            if (cam.state == RollState.LOADED && cam.shot > 0)
                                OutlinedButton(onClick = { vm.finishRoll() }) { Text("Finish roll") }
                            if (cam.state == RollState.LOADED && cam.shot == 0)
                                OutlinedButton(onClick = { vm.openShelf(ShelfMode.LOAD) }) { Text("Swap roll") }
                        }
                        if (cam.state == RollState.FINISHED)
                            Text("Roll is full. Open the camera and hold VOL− to rewind it.", color = Amber)
                        Text("VOL+ = shutter   ·   VOL− = wind on   ·   hold VOL− = rewind", color = Dim, fontSize = 12.sp)
                    }
                }
            }
        }
        item { Text("Rolls", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold) }
        if (vm.rolls.isEmpty()) item { Text("Nothing here yet. Load a roll and go shoot.", color = Dim) }
        items(vm.rolls, key = { it.id }) { r -> RollRow(vm, r) }
    }
}

@Composable
fun RollRow(vm: AppVm, r: Roll) {
    Card(colors = CardDefaults.cardColors(containerColor = Ink2)) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.width(14.dp).height(44.dp).clip(RoundedCornerShape(4.dp)).background(Color(r.film.canColor)))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(r.film.title, color = Color.White, fontWeight = FontWeight.SemiBold)
                Text("${r.shot}/${r.total} frames · ${r.dateLabel} · ${r.stateLabel}", color = Dim, fontSize = 12.sp)
            }
            if (r.state >= RollState.REWOUND && r.shot > 0)
                TextButton(onClick = { vm.openDarkroom(r.id) }) { Text(if (r.state == RollState.DEVELOPED) "Re-develop" else "Develop") }
            if (r.printUris.isNotEmpty()) TextButton(onClick = { vm.openPrints(r.id) }) { Text("Prints") }
        }
    }
}

// ------------------------------------------------------------------ SHELF
@Composable
fun Chip(text: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.clip(RoundedCornerShape(50)).background(if (selected) Amber else Ink2)
            .clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 8.dp)
    ) { Text(text, color = if (selected) Color.Black else Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold) }
}

@Composable
fun ShelfScreen(vm: AppVm) {
    var shelf by remember { mutableStateOf(Shelf.NEG) }
    val films = remember(shelf) { Films.all.filter { it.shelf == shelf } }
    var frames by remember { mutableStateOf(36) }
    val pager = rememberPagerState(pageCount = { films.size })
    LaunchedEffect(shelf) { pager.scrollToPage(0) }
    val loading = vm.shelfMode == ShelfMode.LOAD
    Column(Modifier.fillMaxSize().padding(vertical = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(if (loading) "Load a roll" else "Develop with…", color = Amber, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        LazyRow(contentPadding = PaddingValues(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(Shelf.values().toList()) { s -> Chip(s.label, s == shelf) { shelf = s } }
        }
        HorizontalPager(
            state = pager, modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(horizontal = 100.dp)
        ) { page ->
            val f = films.getOrNull(page)
            val off = (pager.currentPage - page) + pager.currentPageOffsetFraction
            Box(
                Modifier.fillMaxSize().graphicsLayer {
                    rotationY = (-off * 40f).coerceIn(-60f, 60f)
                    val s = 1f - abs(off).coerceAtMost(1f) * 0.25f
                    scaleX = s; scaleY = s; alpha = 1f - abs(off).coerceAtMost(1f) * 0.5f
                },
                contentAlignment = Alignment.Center
            ) { if (f != null) Canister(f) }
        }
        val cur = films.getOrNull(pager.currentPage)
        if (cur != null) {
            Text(cur.title, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text("ISO ${cur.iso}  ·  ${cur.shelf.label}", color = Dim)
        }
        Spacer(Modifier.height(8.dp))
        if (loading) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(12, 24, 36).forEach { n -> Chip("$n exp", frames == n) { frames = n } }
        }
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedButton(onClick = { vm.back() }) { Text("Cancel") }
            Button(enabled = cur != null, onClick = { cur?.let { vm.pickFilm(it, frames) } }) {
                Text(if (loading) "Load roll" else "Develop with this")
            }
        }
    }
}

// ------------------------------------------------------------------ SETTINGS
@Composable
private fun SwitchRow(title: String, sub: String, on: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontWeight = FontWeight.SemiBold)
            Text(sub, color = Dim, fontSize = 12.sp)
        }
        Switch(checked = on, onCheckedChange = onChange)
    }
}

@Composable
fun SettingsScreen(vm: AppVm) {
    val p = vm.prefs
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { vm.back() }) { Text("‹ Back") }
            Text("Settings", color = Amber, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        }
        SwitchRow("Realistic film mode", "Full roll must be rewound (hold VOL−) before developing. Off = Basic: last frame goes straight to the darkroom.", p.realistic) { p.putBool("realistic", it) }
        SwitchRow("Manual wind (VOL−)", "Off = film winds itself after every shot.", p.manualWind) { p.putBool("manualWind", it) }
        SwitchRow("Date stamp on prints", "Orange 'yy MM dd in the corner.", p.dateStamp) { p.putBool("dateStamp", it) }
        SwitchRow("Half-size prints (~3 MP)", "Develops about 3x faster, smaller files.", p.halfSize) { p.putBool("halfSize", it) }
        SwitchRow("Shutter & wind sounds", "Click and winder sound.", p.sound) { p.putBool("sound", it) }
        Column {
            Text("JPEG quality: ${p.quality}", color = Color.White, fontWeight = FontWeight.SemiBold)
            Slider(value = p.quality.toFloat(), onValueChange = { p.putQuality(it.toInt()) }, valueRange = 80f..100f)
        }
        Text("What does the camera see?", color = Color.White, fontWeight = FontWeight.SemiBold)
        Text(vm.camera.diag(), color = Dim, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
        Text("RAW frames are kept in Android/data/com.mfilm.android/files/rolls/. Prints go to Pictures/M-Film/.", color = Dim, fontSize = 12.sp)
    }
}

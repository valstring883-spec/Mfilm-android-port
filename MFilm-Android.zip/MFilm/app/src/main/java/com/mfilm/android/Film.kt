package com.mfilm.android

import com.mfilm.android.Shelf.*
import kotlin.math.log2

enum class Shelf(val label: String) { NEG("Colour negative"), SLIDE("Slide"), BW("Black & white"), CINE("Cinema") }

/** Parametric film look. Written from scratch – not derived from any LUT or GPL code. */
class Film(
    val id: Int, val brand: String, val name: String, val shelf: Shelf, val iso: Int,
    val sat: Float, val con: Float, val warm: Float, val tint: Float, val fade: Float,
    val shadow: Int, val high: Int, val grain: Float, val hal: Float, val soft: Float,
    val exp: Float, val hue: Float, val redSens: Float
) {
    val title get() = "$brand $name"
    val mono get() = shelf == BW
    val grainAmp get() = grain * (0.015f + 0.012f * log2(iso / 50f)) * (if (mono) 1.35f else 1f)
    val grainSize get() = 1f + 0.3f * log2(iso / 100f).coerceAtLeast(0f)
    val canColor: Int get() = when {
        brand.startsWith("Kodak") -> 0xFFF2B400
        brand.startsWith("Fuji") -> 0xFF2E9E5B
        brand.startsWith("Ilford") -> 0xFFDADADA
        brand.startsWith("Agfa") -> 0xFFD6342C
        brand.startsWith("Lomo") -> 0xFFB0B0B0
        brand.startsWith("Cine") -> 0xFFC0392B
        brand.startsWith("Cross") -> 0xFF7E57C2
        else -> 0xFF8A8F98
    }.toInt()
}

object Films {
    val all: List<Film> by lazy { build() }

    private const val N = 0x808080 // neutral tint

    private fun build(): List<Film> {
        val l = ArrayList<Film>()
        fun a(
            b: String, n: String, s: Shelf, iso: Int, sat: Float = 1f, con: Float = 1f, warm: Float = 0f,
            tint: Float = 0f, fade: Float = 0f, sh: Int = N, hi: Int = N, g: Float = 1f, hal: Float = 0f,
            soft: Float = 0f, exp: Float = 0f, hue: Float = 0f, rs: Float = 0f
        ) { l.add(Film(l.size, b, n, s, iso, sat, con, warm, tint, fade, sh, hi, g, hal, soft, exp, hue, rs)) }

        // ---- Colour negative (28) ----
        a("Kodak","Portra 160",NEG,160, sat=.88f,con=.88f,warm=.05f,fade=.02f,sh=0x7A8284,hi=0x8C8478,g=.7f,soft=.05f)
        a("Kodak","Portra 400",NEG,400, sat=.92f,con=.92f,warm=.06f,fade=.02f,sh=0x7A8082,hi=0x8E8576,g=.8f,hal=.05f,soft=.06f,exp=.1f)
        a("Kodak","Portra 800",NEG,800, sat=.95f,con=.95f,warm=.07f,fade=.02f,sh=0x788084,hi=0x908474,g=.9f,hal=.1f,soft=.08f,exp=.15f)
        a("Kodak","Ektar 100",NEG,100, sat=1.3f,con=1.12f,warm=.03f,hi=0x8A8478,g=.7f)
        a("Kodak","Gold 100",NEG,100, sat=1.05f,con=1.02f,warm=.12f,hi=0x948470)
        a("Kodak","Gold 200",NEG,200, sat=1.1f,con=1.05f,warm=.16f,fade=.02f,sh=0x827E78,hi=0x988468,hal=.05f)
        a("Kodak","UltraMax 400",NEG,400, sat=1.12f,con=1.08f,warm=.1f,tint=-.02f,hi=0x94846E)
        a("Kodak","ColorPlus 200",NEG,200, warm=.12f,fade=.03f,sh=0x7E8280,hi=0x928470)
        a("Kodak","Pro Image 100",NEG,100, sat=1.05f,con=1.05f,warm=.06f,sh=0x7E8280)
        a("Kodak","Royal Gold 400",NEG,400, sat=1.1f,con=1.05f,warm=.14f,hi=0x968468)
        a("Kodak","Funsaver 800",NEG,800, sat=1.15f,con=1.1f,warm=.08f,tint=-.04f,fade=.03f,g=1.3f,soft=.1f)
        a("Fujifilm","Superia 200",NEG,200, sat=1.05f,con=1.05f,warm=-.02f,tint=.06f,sh=0x768682,hi=0x868680)
        a("Fujifilm","Superia 400",NEG,400, sat=1.08f,con=1.08f,warm=-.03f,tint=.08f,sh=0x748882)
        a("Fujifilm","Superia 800",NEG,800, sat=1.1f,con=1.1f,warm=-.02f,tint=.08f,sh=0x748884,g=1.2f)
        a("Fujifilm","Superia 1600",NEG,1600, sat=1.1f,con=1.12f,tint=.09f,sh=0x728A84,g=1.2f,hal=.1f)
        a("Fujifilm","C200",NEG,200, con=1.05f,warm=-.03f,tint=.05f,sh=0x768684)
        a("Fujifilm","Pro 160NS",NEG,160, sat=.9f,con=.9f,warm=-.01f,tint=.03f,fade=.02f,sh=0x7C8486,hi=0x868A86,soft=.05f)
        a("Fujifilm","Pro 400H",NEG,400, sat=.92f,con=.9f,warm=-.05f,tint=.05f,fade=.03f,sh=0x788688,hi=0x84888A,soft=.08f,exp=.2f)
        a("Fujifilm","Reala 100",NEG,100, tint=.02f)
        a("Fujifilm","Natura 1600",NEG,1600, sat=.95f,con=.95f,warm=-.02f,tint=.03f,g=1.2f,hal=.08f,soft=.06f)
        a("Agfa","Vista 200",NEG,200, sat=1.12f,con=1.08f,warm=.1f,tint=-.03f,hi=0x90827A)
        a("Agfa","Vista Plus 400",NEG,400, sat=1.1f,con=1.1f,warm=.08f,tint=-.03f)
        a("Agfa","Optima 200",NEG,200, sat=.95f,warm=.04f)
        a("Lomography","Color Negative 100",NEG,100, sat=1.2f,con=1.15f,warm=.04f,tint=.03f,hal=.08f)
        a("Lomography","Color Negative 400",NEG,400, sat=1.2f,con=1.18f,warm=.05f,tint=.03f,hal=.1f)
        a("Lomography","Color Negative 800",NEG,800, sat=1.2f,con=1.18f,warm=.08f,g=1.2f,hal=.12f)
        a("Lomography","Redscale 100",NEG,100, sat=1.3f,con=1.15f,warm=1.4f,tint=-.1f,fade=.03f,hi=0xA08060)
        a("Konica","Centuria 400",NEG,400, sat=1.08f,con=1.05f,tint=.04f,sh=0x788482)

        // ---- Slide (16) ----
        a("Fujifilm","Velvia 50",SLIDE,50, sat=1.55f,con=1.28f,warm=.02f,tint=-.02f,g=.6f,exp=-.1f)
        a("Fujifilm","Velvia 100",SLIDE,100, sat=1.4f,con=1.22f,warm=.01f,tint=-.02f,g=.6f,exp=-.05f)
        a("Fujifilm","Provia 100F",SLIDE,100, sat=1.15f,con=1.12f,warm=-.02f,g=.6f)
        a("Fujifilm","Astia 100F",SLIDE,100, sat=.98f,warm=.02f,g=.6f,soft=.03f)
        a("Fujifilm","Sensia 100",SLIDE,100, sat=1.1f,con=1.1f,warm=-.03f)
        a("Fujifilm","Provia 400X",SLIDE,400, sat=1.15f,con=1.14f,warm=-.02f,g=.9f)
        a("Kodak","Ektachrome E100",SLIDE,100, sat=1.1f,con=1.1f,warm=-.06f,sh=0x6E7888,g=.6f)
        a("Kodak","Ektachrome 100VS",SLIDE,100, sat=1.45f,con=1.2f,warm=-.02f,g=.6f)
        a("Kodak","Kodachrome 25",SLIDE,25, sat=1.2f,con=1.28f,warm=.08f,tint=-.01f,sh=0x6A7078,hi=0x948272,g=.5f)
        a("Kodak","Kodachrome 64",SLIDE,64, sat=1.18f,con=1.25f,warm=.09f,sh=0x6C727A,hi=0x968272,g=.6f)
        a("Kodak","Kodachrome 200",SLIDE,200, sat=1.15f,con=1.22f,warm=.1f,hi=0x968272,g=.9f)
        a("Agfa","Precisa 100",SLIDE,100, sat=1.15f,con=1.1f,warm=-.03f,tint=-.02f,sh=0x707484)
        a("Lomography","LomoChrome Purple",SLIDE,200, sat=1.2f,con=1.12f,hue=100f,g=1.1f,hal=.05f)
        a("Lomography","LomoChrome Metropolis",SLIDE,200, sat=.55f,con=1.3f,fade=.06f,warm=-.04f,hal=.05f)
        a("Lomography","LomoChrome Turquoise",SLIDE,200, sat=1.1f,con=1.12f,hue=-140f,g=1.1f)
        a("Cross-processed","E-6 in C-41",SLIDE,100, sat=1.35f,con=1.35f,warm=-.15f,tint=.12f,sh=0x60708A,hi=0x8A9A6A)

        // ---- Black & white (20) ----
        a("Kodak","Tri-X 400",BW,400, con=1.28f,g=1.4f,rs=.2f)
        a("Kodak","T-Max 100",BW,100, con=1.1f,g=.5f)
        a("Kodak","T-Max 400",BW,400, con=1.12f,g=.7f)
        a("Kodak","T-Max 3200",BW,3200, con=1.15f,g=.9f,hal=.1f,soft=.05f)
        a("Kodak","Plus-X 125",BW,125, con=1.1f)
        a("Ilford","HP5 Plus 400",BW,400, con=1.15f,fade=.02f,g=1.2f)
        a("Ilford","FP4 Plus 125",BW,125, con=1.08f)
        a("Ilford","Delta 100",BW,100, con=1.05f,g=.5f)
        a("Ilford","Delta 400",BW,400, con=1.1f,g=.8f)
        a("Ilford","Delta 3200",BW,3200, con=1.12f,g=.9f,hal=.08f)
        a("Ilford","Pan F Plus 50",BW,50, con=1.12f,g=.6f)
        a("Ilford","XP2 Super 400",BW,400, warm=.02f,fade=.02f)
        a("Ilford","SFX 200",BW,200, con=1.2f,rs=1f,hal=.15f,soft=.12f)
        a("Fujifilm","Neopan Acros 100",BW,100, con=1.1f,g=.4f)
        a("Fujifilm","Neopan 400",BW,400, con=1.12f)
        a("Agfa","APX 100",BW,100, con=1.12f,warm=.01f)
        a("Kentmere","Pan 400",BW,400, con=1.12f,fade=.03f,g=1.2f)
        a("Rollei","Retro 80S",BW,80, con=1.15f,rs=.6f,hal=.05f)
        a("Rollei","RPX 400",BW,400, con=1.1f)
        a("Foma","Fomapan 100",BW,100, con=1.1f,fade=.03f,g=1.2f)

        // ---- Cinema (8) ----
        a("Kodak","Vision3 50D",CINE,50, con=1.05f,warm=.02f,g=.5f)
        a("Kodak","Vision3 250D",CINE,250, con=1.05f,warm=.02f,g=.7f)
        a("Kodak","Vision3 200T",CINE,200, con=1.05f,warm=-.12f,g=.7f)
        a("Kodak","Vision3 500T",CINE,500, con=1.08f,warm=-.1f,g=.9f,hal=.15f)
        a("Kodak","Vision 2383 Print",CINE,100, sat=1.1f,con=1.25f,fade=.03f,sh=0x587A7A,hi=0x9A8068)
        a("CineStill","800T",CINE,800, sat=1.05f,con=1.1f,warm=-.2f,sh=0x6A7A96,hi=0x8A8A8A,g=1.1f,hal=.5f)
        a("CineStill","50D",CINE,50, sat=1.05f,con=1.08f,hal=.3f,g=.5f)
        a("Fujifilm","Eterna Vivid 500",CINE,500, sat=1.3f,con=1.1f,warm=-.04f,g=.9f)
        return l
    }
}

package com.mfilm.android

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.util.Size
import android.view.SurfaceHolder
import android.view.SurfaceView
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

// ------------------------------------------------------------------ CAMERA
@Composable
fun CameraScreen(vm: AppVm) {
    val ctx = LocalContext.current
    var granted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    LaunchedEffect(Unit) { if (!granted) launcher.launch(Manifest.permission.CAMERA) }
    val roll = vm.inCamera

    Column(Modifier.fillMaxSize().background(Color.Black)) {
        Box(Modifier.fillMaxWidth().aspectRatio(3f / 4f).background(Color(0xFF050505))) {
            if (granted && roll != null) Viewfinder(vm)
            if (roll == null) Text("No roll in the camera", color = Dim, modifier = Modifier.align(Alignment.Center))
            else if (!granted) Button(onClick = { launcher.launch(Manifest.permission.CAMERA) }, modifier = Modifier.align(Alignment.Center)) { Text("Allow camera") }
            if (roll != null) ViewfinderOverlay(vm, roll)
            TextButton(onClick = { vm.back() }, modifier = Modifier.align(Alignment.TopStart)) { Text("‹ Home", color = Color.White) }
            Toast(vm)
        }
        TopPlate(vm, roll)
    }
}

@Composable
private fun BoxScope.Toast(vm: AppVm) {
    val n = vm.note ?: return
    var shown by remember(n.id) { mutableStateOf(true) }
    LaunchedEffect(n.id) { delay(1800); shown = false }
    if (shown) Text(
        n.text, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp,
        modifier = Modifier.align(Alignment.Center).clip(RoundedCornerShape(10.dp))
            .background(Color(0xCC000000)).padding(horizontal = 16.dp, vertical = 10.dp)
    )
}

@Composable
private fun Viewfinder(vm: AppVm) {
    val cam = vm.camera
    DisposableEffect(Unit) { onDispose { cam.closeBlocking() } }
    AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = { c ->
            SurfaceView(c).apply {
                holder.setFixedSize(cam.previewSize.width, cam.previewSize.height)
                holder.addCallback(object : SurfaceHolder.Callback {
                    override fun surfaceCreated(h: SurfaceHolder) {}
                    override fun surfaceChanged(h: SurfaceHolder, f: Int, w: Int, hh: Int) {
                        if (w == cam.previewSize.width && hh == cam.previewSize.height) cam.open(h.surface)
                    }
                    override fun surfaceDestroyed(h: SurfaceHolder) { cam.closeBlocking() }
                })
            }
        }
    )
}

@Composable
private fun BoxScope.ViewfinderOverlay(vm: AppVm, roll: Roll) {
    androidx.compose.foundation.Canvas(Modifier.fillMaxSize()) {
        val w = size.width; val h = size.height
        val l = w * 0.22f; val r = w * 0.78f; val t = h * 0.30f; val b = h * 0.70f; val k = w * 0.06f
        val c = Color.White.copy(alpha = 0.8f)
        fun corner(x: Float, y: Float, dx: Float, dy: Float) {
            drawLine(c, Offset(x, y), Offset(x + dx, y), 3f); drawLine(c, Offset(x, y), Offset(x, y + dy), 3f)
        }
        corner(l, t, k, k); corner(r, t, -k, k); corner(l, b, k, -k); corner(r, b, -k, -k)
        drawRect(Brush.verticalGradient(listOf(Color.Transparent, Color(0xAA000000)), startY = h * 0.85f, endY = h),
            topLeft = Offset(0f, h * 0.85f), size = androidx.compose.ui.geometry.Size(w, h * 0.15f))
    }
    Text(vm.camera.let { if (it.rawOk) "RAW · ${it.stillSize.width}×${it.stillSize.height}" else "JPEG · ${it.stillSize.width}×${it.stillSize.height}" },
        color = Color.White.copy(alpha = 0.85f), fontSize = 11.sp, modifier = Modifier.align(Alignment.BottomStart).padding(10.dp))
    Text(roll.film.title, color = Color.White.copy(alpha = 0.85f), fontSize = 11.sp, modifier = Modifier.align(Alignment.BottomEnd).padding(10.dp))
}

@Composable
private fun ColumnScope.TopPlate(vm: AppVm, roll: Roll?) {
    val sp = AppVm.speeds[vm.shutterIdx]
    val stops = vm.meterStops()
    val ns = vm.effectiveNs()
    val effLabel = if (ns > 0) "≈ 1/${(1e9 / ns).toInt().coerceAtLeast(1)} s" else ""
    val windLamp = roll != null && roll.state == RollState.LOADED && !roll.wound && roll.shot < roll.total
    val blink by rememberInfiniteTransition(label = "blink").animateFloat(
        0.25f, 1f, infiniteRepeatable(tween(500), RepeatMode.Reverse), label = "b"
    )
    val counter = when {
        roll == null -> "  "
        roll.state == RollState.FINISHED -> "End"
        roll.counter == 0 -> " S"
        else -> "%2d".format(roll.counter)
    }
    Column(
        Modifier.fillMaxWidth().weight(1f).background(Brush.verticalGradient(listOf(Color(0xFF242424), Color(0xFF0A0A0A))))
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("−2", color = Dim, fontSize = 10.sp); Box(Modifier.weight(1f)) { LightMeter(stops) }; Text("+2", color = Dim, fontSize = 10.sp)
        }
        ApertureScale(vm.camera.fnum)
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Column { Text("SHUTTER $effLabel", color = Dim, fontSize = 10.sp); Seg7(sp.seg, Amber, 44.dp) }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("f/${"%.1f".format(vm.camera.fnum)}   ISO ${roll?.film?.iso ?: "–"}", color = Dim, fontSize = 11.sp)
                Text("WIND ON", color = LampRed.copy(alpha = if (windLamp) blink else 0.12f), fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
            Column(horizontalAlignment = Alignment.End) { Text("FRAME / ${roll?.total ?: 0}", color = Dim, fontSize = 10.sp); Seg7(counter, LampRed, 44.dp) }
        }
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            items(AppVm.speeds.size) { i -> Chip(AppVm.speeds[i].label, vm.shutterIdx == i) { vm.shutterIdx = i } }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedButton(onClick = { vm.wind() }, modifier = Modifier.weight(1f)) { Text("↻ WIND  (VOL −)", fontSize = 12.sp) }
            Button(
                onClick = { vm.shutter() }, modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = LampRed)
            ) { Text("● SHUTTER  (VOL +)", fontSize = 12.sp, color = Color.White) }
        }
        Text("Hold VOL− = rewind" + if (!vm.camera.rawOk) "  ·  RAW not available, shooting JPEG" else "", color = Dim, fontSize = 11.sp)
    }
}

// ------------------------------------------------------------------ DARKROOM
private val SafeRed = Color(0xFFFF4D4D)
private val DarkBg = Color(0xFF140000)

@Composable
fun DarkroomScreen(vm: AppVm) {
    val roll = vm.selected
    val view = LocalView.current
    DisposableEffect(Unit) { view.keepScreenOn = true; onDispose { view.keepScreenOn = false } }
    if (roll == null) { Text("No roll selected", color = SafeRed, modifier = Modifier.padding(24.dp)); return }
    val film = vm.devFilm ?: roll.film
    val d = vm.dev
    Column(
        Modifier.fillMaxSize().background(DarkBg).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { vm.back() }) { Text("‹ Back", color = SafeRed) }
            Text("DARKROOM", color = SafeRed, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        }
        Text("${roll.film.title} · ${roll.shot} frames", color = SafeRed.copy(alpha = 0.8f))
        Text("Develop as: ${film.title}", color = SafeRed, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
        Text("Your RAW frames are untouched, so you can develop the same roll again with any other film.", color = SafeRed.copy(alpha = 0.6f), fontSize = 12.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedButton(enabled = !d.running, onClick = { vm.openShelf(ShelfMode.DEVELOP) }) { Text("Change film", color = SafeRed) }
            if (d.running) OutlinedButton(onClick = { vm.stopDevelop() }) { Text("Stop", color = SafeRed) }
            else Button(
                onClick = { vm.develop(roll, film) },
                colors = ButtonDefaults.buttonColors(containerColor = SafeRed)
            ) { Text(if (d.finished) "Develop again" else "Develop", color = Color.Black) }
        }
        if (d.total > 0) {
            LinearProgressIndicator(progress = { d.done / d.total.toFloat() }, color = SafeRed, trackColor = Color(0xFF3A0000), modifier = Modifier.fillMaxWidth())
            Text("Frame ${d.done} of ${d.total}", color = SafeRed)
        }
        d.error?.let { Text("Error: $it", color = Color.White) }
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(d.thumbs) { b ->
                Image(b.asImageBitmap(), null, Modifier.height(110.dp).clip(RoundedCornerShape(4.dp)), contentScale = ContentScale.Fit)
            }
        }
        if (d.finished) {
            Text("Done. Prints + contact sheet are in Pictures/M-Film/.", color = SafeRed)
            Button(onClick = { vm.openPrints(roll.id) }, colors = ButtonDefaults.buttonColors(containerColor = SafeRed)) { Text("See prints", color = Color.Black) }
        }
    }
}

// ------------------------------------------------------------------ PRINTS
@Composable
private fun UriThumb(uri: String, size: Int, modifier: Modifier) {
    val ctx = LocalContext.current
    val bmp by produceState<Bitmap?>(null, uri) {
        value = withContext(Dispatchers.IO) { runCatching { ctx.contentResolver.loadThumbnail(Uri.parse(uri), Size(size, size), null) }.getOrNull() }
    }
    Box(modifier.background(Ink2)) {
        bmp?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
    }
}

@Composable
fun PrintsScreen(vm: AppVm) {
    val roll = vm.selected
    var open by remember { mutableStateOf<Int?>(null) }
    if (roll == null) { Text("No roll selected", color = Dim, modifier = Modifier.padding(24.dp)); return }
    val o = open
    if (o != null) { Viewer(roll, o) { open = null }; return }
    Column(Modifier.fillMaxSize().padding(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { vm.back() }) { Text("‹ Back") }
            Column {
                Text("Prints", color = Amber, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text(roll.printFilmId.takeIf { it >= 0 }?.let { Films.all[it].title } ?: roll.film.title, color = Dim, fontSize = 12.sp)
            }
        }
        LazyVerticalGrid(GridCells.Fixed(3), horizontalArrangement = Arrangement.spacedBy(4.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            itemsIndexed(roll.printUris) { i, u ->
                Box(Modifier.aspectRatio(1f).clickable { open = i }) {
                    UriThumb(u, 320, Modifier.fillMaxSize())
                    Text("${i + 1}", color = Color(0xFFFF9A2E), fontSize = 11.sp, modifier = Modifier.align(Alignment.BottomStart).padding(4.dp))
                }
            }
        }
    }
}

@Composable
private fun Viewer(roll: Roll, start: Int, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val pager = rememberPagerState(initialPage = start, pageCount = { roll.printUris.size })
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        HorizontalPager(state = pager, modifier = Modifier.fillMaxSize()) { page ->
            val uri = roll.printUris[page]
            val bmp by produceState<Bitmap?>(null, uri) {
                value = withContext(Dispatchers.IO) {
                    runCatching {
                        ImageDecoder.decodeBitmap(ImageDecoder.createSource(ctx.contentResolver, Uri.parse(uri))) { dec, _, _ ->
                            dec.setTargetSampleSize(2)
                        }
                    }.getOrNull()
                }
            }
            bmp?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit) }
        }
        Row(Modifier.align(Alignment.TopStart).fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onClose) { Text("‹ Close", color = Color.White) }
            Spacer(Modifier.weight(1f))
            Text("${pager.currentPage + 1} / ${roll.printUris.size}", color = Color(0xFFFF9A2E))
            TextButton(onClick = {
                val i = Intent(Intent.ACTION_SEND).apply {
                    type = "image/jpeg"; putExtra(Intent.EXTRA_STREAM, Uri.parse(roll.printUris[pager.currentPage]))
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                ctx.startActivity(Intent.createChooser(i, null))
            }) { Text("Share", color = Color.White) }
        }
    }
}

package com.mfilm.android

import android.os.Bundle
import android.view.KeyEvent
import android.view.OrientationEventListener
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier

class MainActivity : ComponentActivity() {
    private val vm: AppVm by viewModels()
    private var longHandled = false
    private lateinit var orient: OrientationEventListener

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        orient = object : OrientationEventListener(this) {
            override fun onOrientationChanged(o: Int) {
                if (o != ORIENTATION_UNKNOWN) vm.deviceRot = ((o + 45) / 90 * 90) % 360
            }
        }
        setContent { MFilmApp(vm) }
    }

    override fun onResume() { super.onResume(); orient.enable() }
    override fun onPause() { super.onPause(); orient.disable() }

    // VOL+ = shutter, VOL- = wind on, hold VOL- = rewind. Only while the camera screen is up.
    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (vm.screen == Screen.CAMERA) when (keyCode) {
            KeyEvent.KEYCODE_VOLUME_UP -> { if (event.repeatCount == 0) vm.shutter(); return true }
            KeyEvent.KEYCODE_VOLUME_DOWN -> {
                if (event.repeatCount == 0) { longHandled = false; event.startTracking() }
                return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onKeyLongPress(keyCode: Int, event: KeyEvent): Boolean {
        if (vm.screen == Screen.CAMERA && keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            longHandled = true; vm.rewind(); return true
        }
        return super.onKeyLongPress(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean {
        if (vm.screen == Screen.CAMERA) when (keyCode) {
            KeyEvent.KEYCODE_VOLUME_UP -> return true
            KeyEvent.KEYCODE_VOLUME_DOWN -> {
                if (!longHandled) vm.wind()
                longHandled = false; return true
            }
        }
        return super.onKeyUp(keyCode, event)
    }
}

@Composable
fun MFilmApp(vm: AppVm) {
    MaterialTheme(colorScheme = darkColorScheme(primary = Amber, background = Ink, surface = Ink)) {
        Surface(Modifier.fillMaxSize(), color = Ink) {
            BackHandler(enabled = vm.screen != Screen.HOME) { vm.back() }
            when (vm.screen) {
                Screen.HOME -> HomeScreen(vm)
                Screen.SHELF -> ShelfScreen(vm)
                Screen.CAMERA -> CameraScreen(vm)
                Screen.DARKROOM -> DarkroomScreen(vm)
                Screen.PRINTS -> PrintsScreen(vm)
                Screen.SETTINGS -> SettingsScreen(vm)
            }
        }
    }
}

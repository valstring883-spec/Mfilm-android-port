package com.mfilm.android

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs
import kotlin.math.log2

val Ink = Color(0xFF0E0E0E)
val Ink2 = Color(0xFF1B1B1B)
val Amber = Color(0xFFE8A200)
val LampRed = Color(0xFFFF3B30)
val Dim = Color(0xFF9A9A9A)

private val SEG = mapOf(
    '0' to 63, '1' to 6, '2' to 91, '3' to 79, '4' to 102, '5' to 109, '6' to 125, '7' to 7, '8' to 127, '9' to 111,
    'S' to 109, 'E' to 121, 'n' to 84, 'd' to 94, 'A' to 119, '-' to 64, ' ' to 0, 'F' to 113
)

/** Seven-segment LCD/LED readout. */
@Composable
fun Seg7(text: String, color: Color, height: Dp, modifier: Modifier = Modifier) {
    Canvas(modifier.size(height * 0.62f * text.length, height)) {
        val hh = size.height; val cw = hh * 0.62f
        val st = hh * 0.11f; val g = st * 0.75f; val pad = st
        text.forEachIndexed { i, ch ->
            val mask = SEG[ch] ?: 0
            val x0 = i * cw + pad; val x1 = (i + 1) * cw - pad
            val y0 = pad; val ym = hh / 2f; val y1 = hh - pad
            fun seg(bit: Int, ax: Float, ay: Float, bx: Float, qy: Float) {
                val on = (mask and bit) != 0
                drawLine(if (on) color else color.copy(alpha = 0.10f), Offset(ax, ay), Offset(bx, qy), st, StrokeCap.Round)
            }
            seg(1, x0 + g, y0, x1 - g, y0)      // a
            seg(2, x1, y0 + g, x1, ym - g)      // b
            seg(4, x1, ym + g, x1, y1 - g)      // c
            seg(8, x0 + g, y1, x1 - g, y1)      // d
            seg(16, x0, ym + g, x0, y1 - g)     // e
            seg(32, x0, y0 + g, x0, ym - g)     // f
            seg(64, x0 + g, ym, x1 - g, ym)     // g
        }
    }
}

/** Needle light meter, -2 … +2 stops. */
@Composable
fun LightMeter(stops: Float, modifier: Modifier = Modifier) {
    val ok = abs(stops) < 0.4f
    Canvas(modifier.fillMaxWidth().height(30.dp)) {
        val w = size.width; val h = size.height
        val cx = w / 2f; val half = w / 2f - 14f
        for (i in -4..4) {
            val x = cx + i / 4f * half
            val big = i % 2 == 0
            drawLine(Color.White.copy(alpha = 0.85f), Offset(x, if (big) 3f else 7f), Offset(x, if (big) 17f else 13f), if (big) 3f else 2f)
        }
        val nx = cx + (stops / 2f).coerceIn(-1.25f, 1.25f) * half
        val p = Path().apply { moveTo(nx, h * 0.42f); lineTo(nx - 9f, h); lineTo(nx + 9f, h); close() }
        drawPath(p, if (ok) Color(0xFF7CFC00) else Amber)
    }
}

/** Aperture scale with a marker at the lens's fixed f-number. */
@Composable
fun ApertureScale(f: Float) {
    val labels = listOf("1.4", "2", "2.8", "4", "5.6", "8", "11", "16")
    val idx = ((log2(f.coerceAtLeast(1f)) - 0.485f) / 0.5f).coerceIn(0f, 7f)
    Column(Modifier.fillMaxWidth()) {
        Canvas(Modifier.fillMaxWidth().height(8.dp)) {
            val x = size.width * (idx / 7f * 0.92f + 0.04f)
            drawPath(Path().apply { moveTo(x - 6f, 0f); lineTo(x + 6f, 0f); lineTo(x, size.height); close() }, Amber)
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            labels.forEach { Text(it, color = Color.White.copy(alpha = 0.8f), fontSize = 10.sp) }
        }
    }
}

/** A film canister standing on the shelf. */
@Composable
fun Canister(f: Film, modifier: Modifier = Modifier) {
    val base = Color(f.canColor)
    val dark = lerp(base, Color.Black, 0.55f)
    val steel = Brush.horizontalGradient(listOf(Color(0xFF666666), Color(0xFFE0E0E0), Color(0xFF666666)))
    Column(modifier.width(150.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.width(112.dp).height(14.dp).clip(RoundedCornerShape(topStart = 5.dp, topEnd = 5.dp)).background(steel))
        Box(
            Modifier.width(150.dp).height(230.dp)
                .background(Brush.horizontalGradient(listOf(dark, base, lerp(base, Color.White, 0.28f), base, dark))),
            contentAlignment = Alignment.Center
        ) {
            Column(
                Modifier.fillMaxWidth(0.82f).background(Color(0xFFF4F1E8)).padding(8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(f.brand.uppercase(), color = Color(0xFF222222), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text(f.name, color = Color(0xFF111111), fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center)
                Text("${f.iso}", color = Color(0xFFB00020), fontSize = 28.sp, fontWeight = FontWeight.Bold)
            }
        }
        Box(Modifier.width(112.dp).height(14.dp).clip(RoundedCornerShape(bottomStart = 5.dp, bottomEnd = 5.dp)).background(steel))
    }
}

package com.mfilm.android

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Frame(
    val file: String, val exposureNs: Long, val iso: Int, val fnum: Float,
    val focalMm: Float, val rot: Int, val meter: Float, val time: Long
)

object RollState { const val LOADED = 0; const val FINISHED = 1; const val REWOUND = 2; const val DEVELOPED = 3 }

data class Roll(
    val id: String, val filmId: Int, val total: Int, val created: Long,
    val shot: Int = 0, val wound: Boolean = false, val state: Int = RollState.LOADED,
    val frames: List<Frame> = emptyList(), val printUris: List<String> = emptyList(),
    val printFilmId: Int = -1, val sheetUri: String? = null
) {
    val film: Film get() = Films.all[filmId]
    /** What the frame counter shows: 0 = "S" (start mark). */
    val counter get() = shot + if (wound) 1 else 0
    val dateLabel: String get() = SimpleDateFormat("d MMM yyyy HH:mm", Locale.getDefault()).format(Date(created))
    val stateLabel: String get() = when (state) {
        RollState.LOADED -> "in camera"
        RollState.FINISHED -> "needs rewinding"
        RollState.REWOUND -> "ready to develop"
        else -> "developed"
    }
}

private fun Frame.toJson() = JSONObject().put("file", file).put("t", exposureNs).put("iso", iso)
    .put("f", fnum.toDouble()).put("mm", focalMm.toDouble()).put("rot", rot)
    .put("meter", meter.toDouble()).put("time", time)

private fun JSONObject.toFrame() = Frame(
    getString("file"), getLong("t"), getInt("iso"), getDouble("f").toFloat(),
    getDouble("mm").toFloat(), getInt("rot"), getDouble("meter").toFloat(), getLong("time")
)

private fun Roll.toJson(): JSONObject = JSONObject().put("id", id).put("film", filmId).put("total", total)
    .put("created", created).put("shot", shot).put("wound", wound).put("state", state)
    .put("frames", JSONArray(frames.map { it.toJson() })).put("prints", JSONArray(printUris))
    .put("printFilm", printFilmId).put("sheet", sheetUri ?: JSONObject.NULL)

private fun rollFromJson(j: JSONObject): Roll {
    val fa = j.getJSONArray("frames"); val pa = j.getJSONArray("prints")
    return Roll(
        j.getString("id"), j.getInt("film"), j.getInt("total"), j.getLong("created"),
        j.getInt("shot"), j.getBoolean("wound"), j.getInt("state"),
        (0 until fa.length()).map { fa.getJSONObject(it).toFrame() },
        (0 until pa.length()).map { pa.getString(it) },
        j.optInt("printFilm", -1), if (j.isNull("sheet")) null else j.getString("sheet")
    )
}

/** Each roll = one folder with the RAW frames + roll.json. */
class RollStore(ctx: Context) {
    private val root = File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "rolls").apply { mkdirs() }
    fun dir(id: String) = File(root, id).apply { mkdirs() }

    fun loadAll(): List<Roll> = (root.listFiles() ?: emptyArray()).mapNotNull {
        runCatching { rollFromJson(JSONObject(File(it, "roll.json").readText())) }.getOrNull()
    }.sortedByDescending { it.created }

    fun save(r: Roll) = File(dir(r.id), "roll.json").writeText(r.toJson().toString())

    fun create(film: Film, total: Int): Roll {
        val id = "roll_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        return Roll(id, film.id, total, System.currentTimeMillis()).also { save(it) }
    }

    fun delete(id: String) { File(root, id).deleteRecursively() }
}

class Prefs(ctx: Context) {
    private val p = ctx.getSharedPreferences("mfilm", Context.MODE_PRIVATE)
    var realistic by mutableStateOf(p.getBoolean("realistic", false))
        private set
    var manualWind by mutableStateOf(p.getBoolean("manualWind", true))
        private set
    var dateStamp by mutableStateOf(p.getBoolean("dateStamp", false))
        private set
    var halfSize by mutableStateOf(p.getBoolean("halfSize", false))
        private set
    var sound by mutableStateOf(p.getBoolean("sound", true))
        private set
    var quality by mutableStateOf(p.getInt("quality", 95))
        private set
    var activeRoll: String? = p.getString("active", null)
        private set

    fun putBool(k: String, v: Boolean) {
        p.edit().putBoolean(k, v).apply()
        when (k) {
            "realistic" -> realistic = v
            "manualWind" -> manualWind = v
            "dateStamp" -> dateStamp = v
            "halfSize" -> halfSize = v
            "sound" -> sound = v
        }
    }
    fun putQuality(v: Int) { quality = v; p.edit().putInt("quality", v).apply() }
    fun setActive(id: String?) { activeRoll = id; p.edit().putString("active", id).apply() }
}

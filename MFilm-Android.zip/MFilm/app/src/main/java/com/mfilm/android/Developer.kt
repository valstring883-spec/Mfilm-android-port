package com.mfilm.android

import android.content.ContentValues
import android.content.Context
import android.graphics.*
import android.os.Build
import android.provider.MediaStore
import androidx.exifinterface.media.ExifInterface
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.Random
import java.util.stream.IntStream
import kotlin.math.*

/** The darkroom: RAW/DNG -> film print. Pure CPU, multi-threaded, no native code. */
object Developer {
    private const val GT = 1024            // grain tile edge
    private const val GMASK = GT * GT - 1

    fun decode(file: File, sample: Int): Bitmap {
        val bmp = try {
            ImageDecoder.decodeBitmap(ImageDecoder.createSource(file)) { dec, _, _ ->
                dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                dec.isMutableRequired = true
                dec.setTargetColorSpace(ColorSpace.get(ColorSpace.Named.SRGB))
                if (sample > 1) dec.setTargetSampleSize(sample)
            }
        } catch (e: Exception) {
            val o = BitmapFactory.Options().apply {
                inMutable = true; inSampleSize = sample; inPreferredConfig = Bitmap.Config.ARGB_8888
            }
            BitmapFactory.decodeFile(file.absolutePath, o) ?: throw IllegalStateException("Cannot decode ${file.name}")
        }
        return if (bmp.config == Bitmap.Config.ARGB_8888 && bmp.isMutable) bmp
        else bmp.copy(Bitmap.Config.ARGB_8888, true)!!
    }

    fun develop(src: Bitmap, film: Film, frame: Frame, seed: Int, stamp: Boolean): Bitmap {
        var bmp = src
        // If the decoder ignored the DNG orientation, rotate by hand.
        if ((frame.rot == 90 || frame.rot == 270) && bmp.width > bmp.height) {
            val r = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(frame.rot.toFloat()) }, true)
            bmp.recycle(); bmp = r
            if (!bmp.isMutable) bmp = bmp.copy(Bitmap.Config.ARGB_8888, true)!!
        }
        val w = bmp.width; val h = bmp.height
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)

        // ---- tone tables: exposure bias, white balance gains, S-curve, fade ----
        val L = 1024
        val lut = Array(3) { FloatArray(L) }
        val ex = 2f.pow(film.exp / 2.2f)
        val gain = floatArrayOf(2f.pow(0.35f * film.warm), 2f.pow(0.45f * film.tint), 2f.pow(-0.5f * film.warm))
        val a = ((film.con - 1f) * 2f).coerceIn(-0.6f, 0.9f)
        for (c in 0..2) for (i in 0 until L) {
            var x = (i / (L - 1f) * ex * gain[c]).coerceIn(0f, 1f)
            x += a * x * (1f - x) * (2f * x - 1f)
            lut[c][i] = film.fade + x * (1f - film.fade)
        }
        val lr0 = lut[0]; val lg0 = lut[1]; val lb0 = lut[2]
        val m = colorMatrix(film.sat, film.hue)
        val mono = film.mono
        val wr = 0.30f + 0.25f * film.redSens
        val wb = (0.11f - 0.07f * film.redSens).coerceAtLeast(0.02f)
        val wg = 1f - wr - wb
        val shR = (Color.red(film.shadow) - 128) / 255f * 0.3f
        val shG = (Color.green(film.shadow) - 128) / 255f * 0.3f
        val shB = (Color.blue(film.shadow) - 128) / 255f * 0.3f
        val hiR = (Color.red(film.high) - 128) / 255f * 0.3f
        val hiG = (Color.green(film.high) - 128) / 255f * 0.3f
        val hiB = (Color.blue(film.high) - 128) / 255f * 0.3f

        // ---- low-res layers for softness + halation ----
        val bs = max(4, w / 500)
        val lw = (w + bs - 1) / bs; val lh = (h + bs - 1) / bs
        val soft = film.soft; val hal = film.hal
        val useLow = soft > 0f || hal > 0f
        val lr = FloatArray(if (useLow) lw * lh else 0)
        val lg = FloatArray(lr.size); val lb = FloatArray(lr.size)
        if (useLow) {
            IntStream.range(0, lh).parallel().forEach { brow ->
                val y0 = brow * bs; val y1 = min(h, y0 + bs)
                for (bx in 0 until lw) {
                    val x0 = bx * bs; val x1 = min(w, x0 + bs)
                    var sr = 0f; var sg = 0f; var sb = 0f
                    for (y in y0 until y1) {
                        var i = y * w + x0
                        for (x in x0 until x1) {
                            val p = px[i++]
                            sr += (p shr 16) and 255; sg += (p shr 8) and 255; sb += p and 255
                        }
                    }
                    val n = (y1 - y0) * (x1 - x0) * 255f
                    lr[brow * lw + bx] = sr / n; lg[brow * lw + bx] = sg / n; lb[brow * lw + bx] = sb / n
                }
            }
        }
        val sR = if (soft > 0f) boxBlur(lr, lw, lh, 3, 2) else lr
        val sG = if (soft > 0f) boxBlur(lg, lw, lh, 3, 2) else lg
        val sB = if (soft > 0f) boxBlur(lb, lw, lh, 3, 2) else lb
        val hl = if (hal > 0f) boxBlur(FloatArray(lw * lh) { i ->
            val l = 0.3f * lr[i] + 0.59f * lg[i] + 0.11f * lb[i]
            ((l - 0.72f) / 0.28f).coerceIn(0f, 1f)
        }, lw, lh, 5, 2) else lr
        val gR = 1f; val gG = if (mono) 1f else 0.38f; val gB = if (mono) 1f else 0.12f

        // ---- grain ----
        val tile = grainTile(seed, film.grainSize)
        val rnd = Random(seed.toLong() * 31 + 7)
        val rowOff = IntArray(GT) { rnd.nextInt(GT) }
        val amp = film.grainAmp

        IntStream.range(0, h).parallel().forEach { y ->
            val rowBase = (y and (GT - 1)) * GT
            val off = rowOff[y and (GT - 1)]
            val fy = ((y + 0.5f) / bs - 0.5f).coerceIn(0f, max(0, lh - 1).toFloat())
            val y0 = fy.toInt(); val y1 = min(lh - 1, y0 + 1); val wy = fy - y0
            var i = y * w
            for (x in 0 until w) {
                val p = px[i]
                var r = ((p shr 16) and 255) * (1f / 255f)
                var g = ((p shr 8) and 255) * (1f / 255f)
                var b = (p and 255) * (1f / 255f)
                if (mono) { val l = wr * r + wg * g + wb * b; r = l; g = l; b = l }
                else {
                    val nr = m[0] * r + m[1] * g + m[2] * b
                    val ng = m[3] * r + m[4] * g + m[5] * b
                    val nb = m[6] * r + m[7] * g + m[8] * b
                    r = nr; g = ng; b = nb
                }
                if (useLow) {
                    val fx = ((x + 0.5f) / bs - 0.5f).coerceIn(0f, max(0, lw - 1).toFloat())
                    val x0 = fx.toInt(); val x1 = min(lw - 1, x0 + 1); val wx = fx - x0
                    val i00 = y0 * lw + x0; val i01 = y0 * lw + x1; val i10 = y1 * lw + x0; val i11 = y1 * lw + x1
                    val w00 = (1 - wx) * (1 - wy); val w01 = wx * (1 - wy); val w10 = (1 - wx) * wy; val w11 = wx * wy
                    if (soft > 0f) {
                        r += (sR[i00] * w00 + sR[i01] * w01 + sR[i10] * w10 + sR[i11] * w11 - r) * soft
                        g += (sG[i00] * w00 + sG[i01] * w01 + sG[i10] * w10 + sG[i11] * w11 - g) * soft
                        b += (sB[i00] * w00 + sB[i01] * w01 + sB[i10] * w10 + sB[i11] * w11 - b) * soft
                    }
                    if (hal > 0f) {
                        val k = (hl[i00] * w00 + hl[i01] * w01 + hl[i10] * w10 + hl[i11] * w11) * hal * 0.9f
                        r += k * gR; g += k * gG; b += k * gB
                    }
                }
                r = lr0[(r.coerceIn(0f, 1f) * 1023f).toInt()]
                g = lg0[(g.coerceIn(0f, 1f) * 1023f).toInt()]
                b = lb0[(b.coerceIn(0f, 1f) * 1023f).toInt()]
                val lum = (r + g + b) * 0.3333f
                val ws = (1f - lum) * (1f - lum); val wh = lum * lum
                r += shR * ws + hiR * wh; g += shG * ws + hiG * wh; b += shB * ws + hiB * wh
                val gi = rowBase + ((x + off) and (GT - 1))
                val gw = amp * (0.4f + 2.4f * lum * (1f - lum))
                val n0 = tile[gi]
                if (mono) { val d = n0 * gw; r += d; g += d; b += d }
                else {
                    r += (0.7f * n0 + 0.3f * tile[(gi + 0x2A5) and GMASK]) * gw
                    g += (0.7f * n0 + 0.3f * tile[(gi + 0x61F) and GMASK]) * gw
                    b += (0.7f * n0 + 0.3f * tile[(gi + 0x9D3) and GMASK]) * gw
                }
                px[i] = (255 shl 24) or
                    ((r.coerceIn(0f, 1f) * 255f + 0.5f).toInt() shl 16) or
                    ((g.coerceIn(0f, 1f) * 255f + 0.5f).toInt() shl 8) or
                    (b.coerceIn(0f, 1f) * 255f + 0.5f).toInt()
                i++
            }
        }
        bmp.setPixels(px, 0, w, 0, 0, w, h)

        if (stamp) {
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = 0xFFFF8A1F.toInt(); typeface = Typeface.MONOSPACE
                textSize = min(w, h) * 0.035f; setShadowLayer(textSize * 0.4f, 0f, 0f, 0xAAFF5A00.toInt())
            }
            val t = SimpleDateFormat("''yy MM dd", Locale.US).format(Date(frame.time))
            Canvas(bmp).drawText(t, w - p.measureText(t) - w * 0.04f, h - h * 0.05f, p)
        }
        return bmp
    }

    private fun colorMatrix(s: Float, hueDeg: Float): FloatArray {
        val t = Math.toRadians(hueDeg.toDouble()); val c = cos(t).toFloat(); val n = sin(t).toFloat()
        val hm = floatArrayOf(
            0.213f + c * 0.787f - n * 0.213f, 0.715f - c * 0.715f - n * 0.715f, 0.072f - c * 0.072f + n * 0.928f,
            0.213f - c * 0.213f + n * 0.143f, 0.715f + c * 0.285f + n * 0.140f, 0.072f - c * 0.072f - n * 0.283f,
            0.213f - c * 0.213f - n * 0.787f, 0.715f - c * 0.715f + n * 0.715f, 0.072f + c * 0.928f + n * 0.072f)
        val sm = floatArrayOf(
            0.213f + 0.787f * s, 0.715f - 0.715f * s, 0.072f - 0.072f * s,
            0.213f - 0.213f * s, 0.715f + 0.285f * s, 0.072f - 0.072f * s,
            0.213f - 0.213f * s, 0.715f - 0.715f * s, 0.072f + 0.928f * s)
        val o = FloatArray(9)
        for (r in 0..2) for (k in 0..2) o[r * 3 + k] = sm[r * 3] * hm[k] + sm[r * 3 + 1] * hm[3 + k] + sm[r * 3 + 2] * hm[6 + k]
        return o
    }

    private fun boxBlur(src: FloatArray, w: Int, h: Int, r: Int, passes: Int): FloatArray {
        var a = src.copyOf(); var b = FloatArray(a.size)
        repeat(passes) {
            for (y in 0 until h) for (x in 0 until w) {
                val lo = max(0, x - r); val hi = min(w - 1, x + r); var s = 0f
                for (k in lo..hi) s += a[y * w + k]
                b[y * w + x] = s / (hi - lo + 1)
            }
            for (y in 0 until h) {
                val lo = max(0, y - r); val hi = min(h - 1, y + r)
                for (x in 0 until w) {
                    var s = 0f
                    for (k in lo..hi) s += b[k * w + x]
                    a[y * w + x] = s / (hi - lo + 1)
                }
            }
        }
        return a
    }

    private fun grainTile(seed: Int, size: Float): FloatArray {
        val rnd = Random(seed.toLong())
        var t = FloatArray(GT * GT) { rnd.nextGaussian().toFloat() }
        val r = (size * 0.7f).roundToInt().coerceAtLeast(1)
        val n = 2 * r + 1
        val o = FloatArray(t.size)
        for (y in 0 until GT) {
            val row = y * GT; var s = 0f
            for (k in -r..r) s += t[row + (k + GT) % GT]
            for (x in 0 until GT) { o[row + x] = s / n; s += t[row + (x + r + 1) % GT] - t[row + (x - r + GT) % GT] }
        }
        val o2 = FloatArray(t.size)
        for (x in 0 until GT) {
            var s = 0f
            for (k in -r..r) s += o[((k + GT) % GT) * GT + x]
            for (y in 0 until GT) { o2[y * GT + x] = s / n; s += o[((y + r + 1) % GT) * GT + x] - o[((y - r + GT) % GT) * GT + x] }
        }
        t = o2
        var ss = 0.0; for (v in t) ss += v * v
        val sd = sqrt(ss / t.size).toFloat()
        for (i in t.indices) t[i] /= sd
        return t
    }

    // ---------------------------------------------------------------- output

    fun save(ctx: Context, bmp: Bitmap, folder: String, name: String, film: Film, f: Frame, quality: Int): String {
        val tmp = File(ctx.cacheDir, "$name.jpg")
        FileOutputStream(tmp).use { bmp.compress(Bitmap.CompressFormat.JPEG, quality, it) }
        try {
            ExifInterface(tmp.absolutePath).apply {
                setAttribute(ExifInterface.TAG_MAKE, Build.MANUFACTURER)
                setAttribute(ExifInterface.TAG_MODEL, Build.MODEL)
                setAttribute(ExifInterface.TAG_SOFTWARE, "M-Film Android - ${film.title}")
                if (f.exposureNs > 0) setAttribute(ExifInterface.TAG_EXPOSURE_TIME, (f.exposureNs / 1e9).toString())
                if (f.iso > 0) setAttribute(ExifInterface.TAG_PHOTOGRAPHIC_SENSITIVITY, f.iso.toString())
                if (f.fnum > 0) setAttribute(ExifInterface.TAG_F_NUMBER, f.fnum.toString())
                setAttribute(ExifInterface.TAG_DATETIME_ORIGINAL, SimpleDateFormat("yyyy:MM:dd HH:mm:ss", Locale.US).format(Date(f.time)))
                saveAttributes()
            }
        } catch (_: Exception) { }
        return store(ctx, tmp, folder, "$name.jpg")
    }

    fun saveBitmap(ctx: Context, bmp: Bitmap, folder: String, name: String, quality: Int): String {
        val tmp = File(ctx.cacheDir, "$name.jpg")
        FileOutputStream(tmp).use { bmp.compress(Bitmap.CompressFormat.JPEG, quality, it) }
        return store(ctx, tmp, folder, "$name.jpg")
    }

    private fun store(ctx: Context, tmp: File, folder: String, display: String): String {
        val cr = ctx.contentResolver
        val v = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, display)
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/M-Film/$folder")
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val uri = cr.insert(MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY), v)!!
        cr.openOutputStream(uri)!!.use { o -> tmp.inputStream().use { it.copyTo(o) } }
        v.clear(); v.put(MediaStore.MediaColumns.IS_PENDING, 0)
        cr.update(uri, v, null, null)
        tmp.delete()
        return uri.toString()
    }

    fun contactSheet(thumbs: List<Bitmap>, film: Film, rollName: String): Bitmap {
        val cols = 6; val cw = 300; val ch = 225; val pad = 18; val head = 90; val strip = 44
        val rows = (thumbs.size + cols - 1) / cols
        val W = cols * (cw + pad) + pad
        val H = head + rows * (ch + strip + pad) + pad
        val bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp); c.drawColor(0xFF0B0B0B.toInt())
        val title = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFE8A200.toInt(); textSize = 40f; typeface = Typeface.MONOSPACE }
        val num = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFF9A2E.toInt(); textSize = 26f; typeface = Typeface.MONOSPACE }
        val cell = Paint().apply { color = 0xFF1A1A1A.toInt() }
        val bp = Paint(Paint.FILTER_BITMAP_FLAG)
        c.drawText("${film.title}  |  $rollName", pad.toFloat(), 60f, title)
        thumbs.forEachIndexed { i, t ->
            val cx = (pad + (i % cols) * (cw + pad)).toFloat(); val cy = (head + (i / cols) * (ch + strip + pad)).toFloat()
            c.drawRect(cx, cy, cx + cw, cy + ch + strip, cell)
            val s = min(cw.toFloat() / t.width, ch.toFloat() / t.height)
            val dw = t.width * s; val dh = t.height * s
            c.drawBitmap(t, null, RectF(cx + (cw - dw) / 2, cy + 4 + (ch - dh) / 2, cx + (cw + dw) / 2, cy + 4 + (ch + dh) / 2), bp)
            c.drawText("${i + 1}", cx + 10, cy + ch + 34, num)
        }
        return bmp
    }
}

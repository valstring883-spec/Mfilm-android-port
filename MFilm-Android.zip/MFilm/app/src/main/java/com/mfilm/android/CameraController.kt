package com.mfilm.android

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.ImageFormat
import android.hardware.camera2.*
import android.media.Image
import android.media.ImageReader
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import android.util.Size
import android.view.Surface
import android.view.SurfaceHolder
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.exifinterface.media.ExifInterface
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.hypot

class AeReading(val timeNs: Long, val iso: Int)

/**
 * Camera2 wrapper. Picks the MAIN back camera (the lens whose 35mm-equivalent focal length is
 * closest to 26mm – the 12MP f/1.8 wide on the S21 FE), shoots RAW/DNG when the device exposes it
 * and falls back to full-quality JPEG otherwise.
 */
class CameraController(ctx: Context) {
    private val mgr = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    private val thread = HandlerThread("mfilm-camera").also { it.start() }
    private val handler = Handler(thread.looper)

    var camId: String? = null; private set
    var chars: CameraCharacteristics? = null; private set
    var rawOk = false; private set
    var stillSize = Size(4000, 3000); private set
    var previewSize = Size(1440, 1080); private set
    var equivMm = 0f; private set
    var sensorOrientation = 90; private set
    var fnum = 1.8f; private set
    private var isoLo = 50; private var isoHi = 3200
    private var tLo = 1_000L; private var tHi = 1_000_000_000L

    /** Latest auto-exposure reading from the preview – used as the light meter. */
    var ae by mutableStateOf(AeReading(8_000_000L, 100))

    private var device: CameraDevice? = null
    private var session: CameraCaptureSession? = null
    private var reader: ImageReader? = null
    private var previewSurface: Surface? = null

    private class Pending(val dest: File, val rot: Int, val done: (Frame?) -> Unit) {
        var res: TotalCaptureResult? = null
        var img: Image? = null
    }
    private var pending: Pending? = null
    private val timeout = Runnable { pending?.let { pending = null; it.done(null) } }

    fun prepare(): Boolean {
        var best: String? = null
        var bestD = Float.MAX_VALUE
        for (id in mgr.cameraIdList) {
            val c = mgr.getCameraCharacteristics(id)
            if (c.get(CameraCharacteristics.LENS_FACING) != CameraCharacteristics.LENS_FACING_BACK) continue
            val caps = c.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES) ?: continue
            if (!caps.contains(CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_BACKWARD_COMPATIBLE)) continue
            val f = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.firstOrNull() ?: continue
            val s = c.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE) ?: continue
            val eq = f * 43.27f / hypot(s.width, s.height)
            val d = abs(eq - 26f)
            if (d < bestD) { bestD = d; best = id; equivMm = eq }
        }
        val id = best ?: return false
        camId = id
        val c = mgr.getCameraCharacteristics(id)
        chars = c
        val map = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP) ?: return false
        val caps = c.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES) ?: IntArray(0)
        val rawSize = map.getOutputSizes(ImageFormat.RAW_SENSOR)?.maxByOrNull { it.width * it.height }
        rawOk = caps.contains(CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_RAW) && rawSize != null
        stillSize = if (rawOk) rawSize!! else
            (map.getOutputSizes(ImageFormat.JPEG) ?: emptyArray()).filter { it.width * it.height <= 12_600_000 }
                .maxByOrNull { it.width * it.height } ?: Size(4000, 3000)
        val prev = map.getOutputSizes(SurfaceHolder::class.java) ?: emptyArray()
        previewSize = prev.filter { it.width * 3 == it.height * 4 && it.width <= 1600 }.maxByOrNull { it.width }
            ?: prev.filter { it.width <= 1920 }.maxByOrNull { it.width * it.height } ?: previewSize
        sensorOrientation = c.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90
        fnum = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_APERTURES)?.firstOrNull() ?: 1.8f
        c.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE)?.let { isoLo = it.lower; isoHi = it.upper }
        c.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE)?.let { tLo = it.lower; tHi = it.upper }
        return true
    }

    @SuppressLint("MissingPermission")
    fun open(surface: Surface) {
        handler.post {
            closeNow()
            val id = camId ?: return@post
            previewSurface = surface
            reader = ImageReader.newInstance(
                stillSize.width, stillSize.height, if (rawOk) ImageFormat.RAW_SENSOR else ImageFormat.JPEG, 2
            ).also { r ->
                r.setOnImageAvailableListener({ rr ->
                    val img = rr.acquireNextImage()
                    val p = pending
                    if (img == null) return@setOnImageAvailableListener
                    if (p == null) { img.close(); return@setOnImageAvailableListener }
                    p.img = img; tryFinish()
                }, handler)
            }
            try {
                mgr.openCamera(id, object : CameraDevice.StateCallback() {
                    override fun onOpened(d: CameraDevice) { device = d; startSession() }
                    override fun onDisconnected(d: CameraDevice) { d.close(); device = null }
                    override fun onError(d: CameraDevice, e: Int) { d.close(); device = null }
                }, handler)
            } catch (e: Exception) { e.printStackTrace() }
        }
    }

    private val previewCb = object : CameraCaptureSession.CaptureCallback() {
        private var last = 0L
        override fun onCaptureCompleted(s: CameraCaptureSession, r: CaptureRequest, res: TotalCaptureResult) {
            val t = res.get(CaptureResult.SENSOR_EXPOSURE_TIME) ?: return
            val i = res.get(CaptureResult.SENSOR_SENSITIVITY) ?: return
            val now = SystemClock.uptimeMillis()
            if (now - last > 150) { last = now; ae = AeReading(t, i) }
        }
    }

    @Suppress("DEPRECATION")
    private fun startSession() {
        val d = device ?: return
        val ps = previewSurface ?: return
        val r = reader ?: return
        try {
            d.createCaptureSession(listOf(ps, r.surface), object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(s: CameraCaptureSession) {
                    session = s
                    val b = d.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
                    b.addTarget(ps)
                    b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
                    b.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON)
                    s.setRepeatingRequest(b.build(), previewCb, handler)
                }
                override fun onConfigureFailed(s: CameraCaptureSession) {}
            }, handler)
        } catch (e: Exception) { e.printStackTrace() }
    }

    /** Manual-exposure still. [timeNs] is the exposure the *film* wants at [filmIso]. */
    fun capture(timeNs: Long, filmIso: Int, rot: Int, dest: File, done: (Frame?) -> Unit) {
        handler.post {
            val d = device; val s = session; val r = reader
            if (d == null || s == null || r == null || pending != null) { done(null); return@post }
            val iso = filmIso.coerceIn(isoLo, isoHi)
            val t = (timeNs.toDouble() * filmIso / iso).toLong().coerceIn(tLo, tHi)
            val p = Pending(dest, rot, done)
            pending = p
            handler.postDelayed(timeout, 10_000)
            try {
                val b = d.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE)
                b.addTarget(r.surface)
                b.set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO)
                b.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF)
                b.set(CaptureRequest.SENSOR_EXPOSURE_TIME, t)
                b.set(CaptureRequest.SENSOR_SENSITIVITY, iso)
                b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
                if (rawOk) b.set(CaptureRequest.STATISTICS_LENS_SHADING_MAP_MODE, CaptureRequest.STATISTICS_LENS_SHADING_MAP_MODE_ON)
                else { b.set(CaptureRequest.JPEG_QUALITY, 100.toByte()); b.set(CaptureRequest.JPEG_ORIENTATION, rot) }
                s.capture(b.build(), object : CameraCaptureSession.CaptureCallback() {
                    override fun onCaptureCompleted(ss: CameraCaptureSession, rq: CaptureRequest, res: TotalCaptureResult) {
                        p.res = res; tryFinish()
                    }
                    override fun onCaptureFailed(ss: CameraCaptureSession, rq: CaptureRequest, f: CaptureFailure) {
                        if (pending === p) { pending = null; handler.removeCallbacks(timeout); p.img?.close(); done(null) }
                    }
                }, handler)
            } catch (e: Exception) {
                pending = null; handler.removeCallbacks(timeout); done(null)
            }
        }
    }

    private fun tryFinish() {
        val p = pending ?: return
        val res = p.res ?: return
        val img = p.img ?: return
        pending = null
        handler.removeCallbacks(timeout)
        try {
            val orient = when (p.rot) {
                90 -> ExifInterface.ORIENTATION_ROTATE_90
                180 -> ExifInterface.ORIENTATION_ROTATE_180
                270 -> ExifInterface.ORIENTATION_ROTATE_270
                else -> ExifInterface.ORIENTATION_NORMAL
            }
            if (rawOk) {
                val dng = DngCreator(chars!!, res)
                try {
                    dng.setOrientation(orient)
                    FileOutputStream(p.dest).use { dng.writeImage(it, img) }
                } finally { dng.close() }
            } else {
                val buf = img.planes[0].buffer
                val bytes = ByteArray(buf.remaining()); buf.get(bytes)
                FileOutputStream(p.dest).use { it.write(bytes) }
                ExifInterface(p.dest.absolutePath).apply {
                    setAttribute(ExifInterface.TAG_ORIENTATION, orient.toString()); saveAttributes()
                }
            }
            img.close()
            p.done(Frame(
                p.dest.name,
                res.get(CaptureResult.SENSOR_EXPOSURE_TIME) ?: 0L,
                res.get(CaptureResult.SENSOR_SENSITIVITY) ?: 0,
                res.get(CaptureResult.LENS_APERTURE) ?: fnum,
                res.get(CaptureResult.LENS_FOCAL_LENGTH) ?: 0f,
                p.rot, 0f, System.currentTimeMillis()
            ))
        } catch (e: Exception) {
            runCatching { img.close() }
            p.done(null)
        }
    }

    private fun closeNow() {
        handler.removeCallbacks(timeout)
        pending?.let { it.img?.close() }
        pending = null
        runCatching { session?.close() }; session = null
        runCatching { device?.close() }; device = null
        runCatching { reader?.close() }; reader = null
    }

    fun closeBlocking() {
        val l = CountDownLatch(1)
        handler.post { closeNow(); l.countDown() }
        l.await(1500, TimeUnit.MILLISECONDS)
    }

    fun diag(): String {
        val c = chars ?: return "No suitable back camera found."
        val lvl = when (c.get(CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL)) {
            CameraMetadata.INFO_SUPPORTED_HARDWARE_LEVEL_FULL -> "FULL"
            CameraMetadata.INFO_SUPPORTED_HARDWARE_LEVEL_3 -> "LEVEL_3"
            CameraMetadata.INFO_SUPPORTED_HARDWARE_LEVEL_LIMITED -> "LIMITED"
            else -> "LEGACY/EXTERNAL"
        }
        val tpl = "camera id: %s\n35mm equiv: %.1f mm\nformat: %s\nstill size: %dx%d (%.1f MP)\npreview: %dx%d\n" +
            "ISO range: %d-%d\nexposure: %d us - %.2f s\nsensor orientation: %d deg\nhardware level: %s"
        return tpl.format(
            camId, equivMm, if (rawOk) "RAW/DNG" else "JPEG (RAW not exposed)", stillSize.width, stillSize.height,
            stillSize.width * stillSize.height / 1e6, previewSize.width, previewSize.height,
            isoLo, isoHi, tLo / 1000, tHi / 1e9, sensorOrientation, lvl
        )
    }
}

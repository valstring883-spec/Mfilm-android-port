# M-Film Android

Viết lại ý tưởng của M-Film (film simulation cho Canon + Magic Lantern) thành app Android thuần.
Viết từ đầu: không dùng code hay LUT của repo gốc.

## Build ra APK
1. Cài **Android Studio** (bản mới, có JDK 17+).
2. `File > Open` thư mục `MFilm`. Nếu Studio hỏi Gradle: dùng **8.9**. Chờ sync.
3. Cắm S21 FE (bật USB debugging) rồi bấm **Run ▶**.
   Hoặc `Build > Build APK(s)` -> `app/build/outputs/apk/debug/app-debug.apk`, gửi vào máy và cài.

## Cách dùng
- **VOL +** = bấm chụp (shutter)
- **VOL −** = lên phim (wind on). Sau mỗi tấm phải lên phim thì mới chụp tiếp được (đèn WIND ON nhấp nháy).
- **Giữ VOL −** = tua phim về (rewind), dùng ở chế độ Realistic.
- Chụp "mù": không có xem lại ảnh. Hết cuộn thì sang Darkroom để tráng.
- Khoảng cách ống kính cố định f/1.8; ISO = ISO của cuộn phim; chỉnh tốc độ màn trập bằng hàng chip dưới HUD
  (A = tự động theo đo sáng). Kim đo sáng báo lệch -2…+2 stop.

## Camera
App tự chọn camera sau có tiêu cự tương đương gần 26mm nhất (cam chính 12MP f/1.8 của S21 FE).
Chụp RAW/DNG nếu máy cho phép, nếu không thì tự chuyển sang JPEG chất lượng 100.
Xem Settings > "What does the camera see?" để biết máy báo gì.

## Nơi lưu
- RAW: `Android/data/com.mfilm.android/files/rolls/<roll>/`
- Ảnh đã tráng + contact sheet: `Pictures/M-Film/<roll>_<film>/`

## Cấu trúc code
| File | Việc |
|---|---|
| `Film.kt` | 72 loại phim (thông số màu, curve, hạt, halation, mềm) |
| `CameraController.kt` | Camera2: chọn cam chính, preview, đo sáng, chụp DNG |
| `Developer.kt` | Darkroom: DNG -> màu phim -> hạt/halation -> JPEG, contact sheet |
| `AppVm.kt` | Logic cuộn phim, nút âm lượng, lên/tua phim, tráng |
| `Hud.kt`, `Screens.kt`, `CameraScreens.kt` | Giao diện Compose |
